﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class CompareProduct : Form
    {
        public CompareProduct()
        {
            InitializeComponent();
            MthdFillDrpProduct();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                try
                {
                    webBrowser1.Navigate(textBox1.Text);
                    webBrowser1.ScriptErrorsSuppressed = true;
                }
                catch (Exception ex)
                {

                }

            }

        }
        private void Navigate(String address)
        {
            if (String.IsNullOrEmpty(address)) return;
            if (address.Equals("about:blank")) return;
            if (!address.StartsWith("http://") &&
                !address.StartsWith("https://"))
            {
                address = "http://" + address;
            }
            try
            {
                webBrowser1.Navigate(new Uri(address));
            }
            catch (System.UriFormatException)
            {
                return;
            }
        }
        private void webBrowser1_Navigated(object sender,
    WebBrowserNavigatedEventArgs e)
        {
            textBox1.Text = webBrowser1.Url.ToString();
        }
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        public void MthdFillDrpProduct()
        {
            DrpProduct.DataSource = (from a in db.tblProducts select new { a.ProductID, a.ProductName }).ToList();
            DrpProduct.ValueMember = "ProductID";
            DrpProduct.DisplayMember = "ProductName";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void CompareProduct_Load(object sender, EventArgs e)
        {
            MthdFillDrpProduct();
        }

        private void DrpProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(DrpProduct.SelectedValue.ToString());
                lblprice.Text = db.SpCheckPrice(id).FirstOrDefault();
            }
            catch (Exception ex)
            {

            }
           
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtWebPrice_TextChanged(object sender, EventArgs e)
        {
            if(txtWebPrice.Text!="")
            {
                double webPrice = double.Parse(txtWebPrice.Text.ToString());
                double productPrice = double.Parse(lblprice.Text.ToString());

                double result = productPrice - webPrice;

                lblComp.Text = result.ToString();
            }
            else
            {
                lblComp.Text = "No Value to Compare";
            }
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtWebPrice.Text.Trim() != "" || textBox1.Text.Trim() != "")
            {
                tblCompareProduct obj = new tblCompareProduct();

                try
                {
                    obj.URL = textBox1.Text;
                    obj.Price = float.Parse(lblprice.Text.ToString());
                    obj.Web_Price = float.Parse(txtWebPrice.Text.ToString());
                    obj.Comparision = float.Parse(lblComp.Text.ToString());

                    obj.ProductID = int.Parse(DrpProduct.SelectedValue.ToString());


                    db.tblCompareProducts.Add(obj);
                    db.SaveChanges();


                    PublicString.Comparision = lblComp.Text;
                    PublicString.Product = DrpProduct.Text.ToString();
                    PublicString.Web_Price = txtWebPrice.Text;
                    PublicString.ProductPrice = lblprice.Text;


                  


                    SendMail form = new SendMail();
                    form.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {

                }

            }
            else
            {
                lblComp.Text = "Empty fields are not allowed!";
                lblComp.ForeColor = System.Drawing.Color.Red;
            }
        



         
        }
        public bool Empty()
        {
            if (txtWebPrice.Text.Trim() == "" || textBox1.Text.Trim() == "")
            {
                lblComp.Visible = true;
                lblComp.Text = "Empty fields are not allowed!";
                lblComp.ForeColor = System.Drawing.Color.Red;
                return true;


            }
            else
            {
                return false;
            }
        }
    }
}
