﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ff = new Form1();
            ff.Show();

        }
        //protected override void OnPaintBackground(PaintEventArgs e)
        //{
        //    using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle,
        //                                                               Color.Blue,
        //                                                               Color.DarkBlue,
        //                                                               90F))
        //    {
        //        e.Graphics.FillRectangle(brush, this.ClientRectangle);
        //    }
        //}
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        private void Form1_Load(object sender, EventArgs e)
        {
            lblname1.Text = "Welcome  "+ PublicString.username;


            var TotalMails = db.tblMails.Count(a => a.MailID > 0).ToString();
            lblTotalMail.Text = TotalMails;

            var TotalUser = db.tblUsers.Count(a => a.UserID > 0).ToString();
            lblTotalUser.Text = TotalUser;

            var TotalProducts = db.tblProducts.Count(a => a.ProductID > 0).ToString();
            lblTotalProducts.Text = TotalProducts;
        }

        private void lblProduct_Click(object sender, EventArgs e)
        {
            openChildForm(new FrmProduct());
        }
        private Form activeForm = null;
        private void openChildForm(Form childform)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            Main.Controls.Add(childform);
            Main.Tag = childform;
            childform.BringToFront();
            childform.Show();

        }

        private void label3_Click(object sender, EventArgs e)
        {
            openChildForm(new FrmMail());
        }

        private void label11_Click(object sender, EventArgs e)
        {
            FrmLogin Login = new FrmLogin();
            Login.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            openChildForm(new UserMangement());
        }

     
   
    }
}
