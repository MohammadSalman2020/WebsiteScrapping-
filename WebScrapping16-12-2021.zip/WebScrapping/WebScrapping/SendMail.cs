﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class SendMail : Form
    {
        public SendMail()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void SendMail_Load(object sender, EventArgs e)
        {
            txtFrom.Text = PublicString.username;
            lblmsg.Visible = false;

            txtSubject.Text = "To notify about product Comparision";


            txtMail.Text = "Dear Sir \n Your Comparision of a Product "+PublicString.Product+" is "+PublicString.Comparision+" \n Web-Price = "+PublicString.Web_Price+"\n Product-Price = "+PublicString.ProductPrice+"\n Regards,\n "+PublicString.username;
        }
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        private void button1_Click(object sender, EventArgs e)
        {

          if(!Empty())
          {
              var rec = db.spGetUserID(txtFrom.Text).FirstOrDefault();


           

              tblMail obj = new tblMail();


              obj.MailFrom = rec;
              obj.MailTo = txtTo.Text;

              obj.MailText = txtMail.Text;
              obj.Subject = txtSubject.Text;
              obj.MailDate = DateTime.Today;


              db.tblMails.Add(obj);
              db.SaveChanges();
              MessageBox.Show("Mail Sent to  " + txtTo.Text);
              this.Hide();
              
          }
          else
          {
              lblmsg.Visible = true;
              lblmsg.Text = "Empty fields are not allowed!";
              lblmsg.ForeColor = System.Drawing.Color.Red;
          }

            
        }
        public bool Empty()
        {
            if (txtTo.Text.Trim() == string.Empty || txtSubject.Text.Trim() == string.Empty || txtMail.Text.Trim() == string.Empty || txtFrom.Text.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Empty fields are not allowed!";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;


            }
            else
            {
                return false;
            }
        }
    }
}
