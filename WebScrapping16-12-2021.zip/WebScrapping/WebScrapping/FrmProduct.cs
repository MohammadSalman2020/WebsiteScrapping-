﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.IO;
using ExcelDataReader;
using Z.Dapper.Plus;
using System.Data.SqlClient;
namespace WebScrapping
{
    public partial class FrmProduct : Form
    {
        public FrmProduct()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CompareProduct Form = new CompareProduct();
            Form.Show();
        }
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        private void FrmProduct_Load(object sender, EventArgs e)
        {

            MTHDFILLGRID();
            lblHiddenFeild.Visible = false;
        }
        DataTableCollection tables;
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            //if(!Empty())
            //{
            //    tblProduct obj = new tblProduct();
            //    obj.ProductName = txtName.Text;
            //    obj.Price = txtprice.Text;

            //    if (int.Parse(txtprice.Text) <= 10)
            //    {
            //        obj.Category = "Deluxe";
            //    }
            //    else if (int.Parse(txtprice.Text) <= 50)
            //    {
            //        obj.Category = "Standard";
            //    }

            //    else if (int.Parse(txtprice.Text) > 50)
            //    {
            //        obj.Category = "Top Line";
            //    }






            //    db.tblProducts.Add(obj);


            //    db.SaveChanges();
            //    lblmsg.Visible = true;
            //    lblmsg.Text = "Product " + txtName.Text + " Added Successfully";
            //    MTHDFILLGRID();
            //}

            //else
            //{
            //    lblmsg.Visible = true;
            //    lblmsg.Text = "Empty fields are not allowed!";
            //    lblmsg.ForeColor = System.Drawing.Color.Red;
            //}



            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel 97-2020 Workbook|*.xls|Excel Workbook|*.xlsx" })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtPath.Text = ofd.FileName;
                    using (var stream = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read))
                    {
                        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });
                            tables = result.Tables;
                            comboBox1.Items.Clear();
                            foreach (DataTable table in tables)
                                comboBox1.Items.Add(table.TableName);
                        }
                    }
                }
            }



        }
        public void MTHDFILLGRID()
        {
            dataGridView1.DataSource = db.spFillGrid().ToList();







        }

        private void txtprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //int x = e.RowIndex;
            //DataGridViewRow sr = dataGridView1.Rows[x];
            //lblHiddenFeild.Text = sr.Cells[0].Value.ToString();
            //txtName.Text = sr.Cells[1].Value.ToString();
            //txtprice.Text = sr.Cells[2].Value.ToString();
            //lblmsg.Text = sr.Cells[3].Value.ToString();

            //btnUpdate.Visible = true;
            //BtnAdd.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //    try
            //    {
            //        int id = int.Parse(lblHiddenFeild.Text);
            //        var row = db.tblProducts.Where(a => a.ProductID == id).FirstOrDefault();
            //        if (row != null)
            //        {
            //            if (!Empty())
            //            {

            //                //   row.CompanyID = int.Parse(DrpCompanyName.SelectedValue.ToString());

            //                row.ProductName = txtName.Text;
            //                row.Price = txtprice.Text;

            //                if (int.Parse(txtprice.Text) <= 10)
            //                {
            //                    row.Category = "Deluxe";
            //                }
            //                else if (int.Parse(txtprice.Text) <= 50)
            //                {
            //                    row.Category = "Standard";
            //                }

            //                else if (int.Parse(txtprice.Text) > 50)
            //                {
            //                    row.Category = "Top Line";
            //                }




            //                db.SaveChanges();
            //                lblmsg.Visible = true;
            //                lblmsg.Text = "Record updated successfully!";
            //                lblmsg.ForeColor = System.Drawing.Color.Green;
            //                txtName.Text = "";
            //                txtprice.Text = "";
            //                btnUpdate.Visible = false;
            //                BtnAdd.Visible = true;
            //                MTHDFILLGRID();
            //            }
            //            else
            //            {
            //                btnUpdate.Visible = true;
            //                BtnAdd.Visible = false;
            //            }

            //        }


            //        MTHDFILLGRID();
            //    }
            //    catch (Exception ex)
            //    {
            //        ex.Message.ToString();
            //    }



            try
            {
                Insert(dataGridView2.DataSource as List<AddProduct>);

                MTHDFILLGRID();


                MessageBox.Show("Finished !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        public string GetCatagory(float x)
        {
            if (x <= 200)
            {
                return "Deluxe";

            }
            else if (x <= 1000)
            {
                return "Standard";
            }
            else
            {
                return "Top Line";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = tables[comboBox1.SelectedItem.ToString()];
            if (dt != null)
            {
                List<AddProduct> list = new List<AddProduct>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    AddProduct obj = new AddProduct();
                    obj.ProductName = dt.Rows[i]["ProductName"].ToString();
                    obj.Price = dt.Rows[i]["Price"].ToString();
                    obj.Category = GetCatagory(float.Parse(dt.Rows[i]["Price"].ToString()));

                    list.Add(obj);
                }
                dataGridView2.DataSource = list;
            }
        }
        public void Insert(List<AddProduct> list)
        {
            DapperPlusManager.Entity<AddProduct>().Table("tblProduct");
            using (IDbConnection db = new SqlConnection("Data Source=DESKTOP-SUJ3QU3;Initial Catalog=DbWebScrapping;Integrated Security=True"))
       
            {
                db.BulkInsert(list);
            }
        }
    }
}
