﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebScrapping
{
    class PublicString
    {
        public static string username = "";

        public static string To = "";

        public static string Product = "";

        public static string Comparision = "";

        public static string Web_Price = "";

        public static string ProductPrice = "";

        public static string From = "";

        public static string User
        {
            get
            {
                return username;
            }
            set
            {
                 username = value;
            }
        }

        public static string MailTo
        {
            get
            {
                return To;
            }
            set
            {
                To = value;
            }
        }
        public static string ProductName
        {
            get
            {
                return Product;
            }
            set
            {
                Product = value;
            }
        }
        public static string ComparePrice
        {
            get
            {
                return Comparision;
            }
            set
            {
                Comparision = value;
            }
        }
        public static string WebPrice
        {
            get
            {
                return Web_Price;
            }
            set
            {
                Web_Price = value;
            }
        }
        public static string ProductCost
        {
            get
            {
                return ProductPrice;
            }
            set
            {
                ProductPrice = value;
            }
        }
        public static string MailFrom
        {
            get
            {
                return From;
            }
            set
            {
                From = value;
            }
        }


    }
}
