﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class UserMangement : Form
    {
        public UserMangement()
        {
            InitializeComponent();
        }
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        private void button1_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                tblUser obj = new tblUser();
                tbllogin obj2 = new tbllogin();


                obj.Firstname = txtFNAme.Text;
                obj.LastName = txtLastNAme.Text;
                obj.Email = txtEmail.Text;
                obj.Pwd = txtPAss.Text;
                obj.U_Address = txtAddress.Text;


                obj2.RoleId = 1;
                obj2.UserName = txtFNAme.Text+" "+txtLastNAme.Text;
                obj2.Email = txtEmail.Text;
                obj2.Pwd = txtPAss.Text;

                db.tblUsers.Add(obj);
                db.tbllogins.Add(obj2);
                db.SaveChanges();
                ClearTextBox();
                MessageBox.Show("User " + txtFNAme.Text + " " + txtLastNAme.Text + "Added Successfully");
            }
            else
            {
                lblComp.Visible = true;
                lblComp.Text = "Empty fields are not allowed!";
                lblComp.ForeColor = System.Drawing.Color.Red;
            }
      

        }
        public bool Empty()
        {
            if (txtPAss.Text.Trim() == string.Empty || txtLastNAme.Text.Trim() == string.Empty || txtFNAme.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty || txtAddress.Text.Trim() == string.Empty)
            {
                lblComp.Visible = true;
                lblComp.Text = "Empty fields are not allowed!";
                lblComp.ForeColor = System.Drawing.Color.Red;
                return true;


            }
            else
            {
                return false;
            }
        }

        public void ClearTextBox()
        {
            txtAddress.Text = "";
            txtEmail.Text = "";
            txtFNAme.Text = "";
            txtLastNAme.Text = "";
            txtPAss.Text = "";
        }

        private void UserMangement_Load(object sender, EventArgs e)
        {
            lblComp.Visible = false;
        }
    }
}
