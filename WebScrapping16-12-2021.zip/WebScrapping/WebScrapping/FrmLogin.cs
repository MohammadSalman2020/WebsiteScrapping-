﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DbWebScrappingEntities db = new DbWebScrappingEntities();


            var rec = db.tbllogins.Where(p => p.Email == txtUsername.Text && p.Pwd == txtPwd.Text).FirstOrDefault();
            if(rec!=null)
            {


                PublicString.username = txtUsername.Text;


                Form1 Dashboard = new Form1();
                Dashboard.Show();
                this.Hide();
             
                
            }
            else
            {
                MessageBox.Show("Username or Password not exists");
            }

        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            lblname.Visible = false;
        }

       
    }
}
