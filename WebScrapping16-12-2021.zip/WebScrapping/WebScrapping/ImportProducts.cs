﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Z.Dapper.Plus;

namespace WebScrapping
{
    public partial class ImportProducts : Form
    {
        public ImportProducts()
        {
            InitializeComponent();
        }
        DataTableCollection tables;
        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel 97-2020 Workbook|*.xls|Excel Workbook|*.xlsx" })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtPath.Text = ofd.FileName;
                    using (var stream = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read))
                    {
                        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });
                            tables = result.Tables;
                            comboBox1.Items.Clear();
                            foreach (DataTable table in tables)
                                comboBox1.Items.Add(table.TableName);
                        }
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = tables[comboBox1.SelectedItem.ToString()];
            if (dt != null)
            {
                List<AddProduct> list = new List<AddProduct>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    AddProduct obj = new AddProduct();
                    obj.ProductName = dt.Rows[i]["ProductName"].ToString();
                    obj.Price = dt.Rows[i]["Price"].ToString();

                 
                   





                    list.Add(obj);
                }
                dataGridView1.DataSource = list;
            }
        }
        public void Insert(List<AddProduct> list)
        {
            DapperPlusManager.Entity<AddProduct>().Table("tblProduct");
            using (IDbConnection db = new SqlConnection("Data Source=DESKTOP-SUJ3QU3;Initial Catalog=DbWebScrapping;Integrated Security=True"))
            {
                db.BulkInsert(list);
            }
        }
        private void ImportProducts_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbWebScrappingDataSet.tblProduct' table. You can move, or remove it, as needed.
            this.tblProductTableAdapter.Fill(this.dbWebScrappingDataSet.tblProduct);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Insert(dataGridView1.DataSource as List<AddProduct>);







                MessageBox.Show("Finished !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
