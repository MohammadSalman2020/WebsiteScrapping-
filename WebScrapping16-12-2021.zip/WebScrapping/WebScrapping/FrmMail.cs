﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebScrapping
{
    public partial class FrmMail : Form
    {
        public FrmMail()
        {
            InitializeComponent();
        }
        DbWebScrappingEntities db = new DbWebScrappingEntities();
        public void FillGrid()
        {
            dataGridView1.DataSource = db.SpFillMailGridMailID().ToList();
        }

        private void FrmMail_Load(object sender, EventArgs e)
        {
            FillGrid();
            lblHiddenField.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
    {
        int x = e.RowIndex;
        DataGridViewRow sr = dataGridView1.Rows[x];



        lblHiddenField.Text = sr.Cells[0].Value.ToString();
        lblFrom.Text = sr.Cells[1].Value.ToString();
        //lblSubject.Text = sr.Cells[5].Value.ToString();
        //lblTo.Text = sr.Cells[3].Value.ToString();
        //lblDate.Text = sr.Cells[4].Value.ToString();


        int id = int.Parse(lblHiddenField.Text);
        
        tblMail obj1 = db.tblMails.FirstOrDefault(r => r.MailID == id);

        //   DrpCompanyName.SelectedValue = obj1.CompanyID.ToString();

        lblSubject.Text = obj1.Subject;
        lblTo.Text = obj1.MailTo;

        string test = obj1.MailDate.ToString();
        lblDate.Text = DateTime.Parse(test).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

        lblMail.Text = obj1.MailText;

      



    }


    }
}
